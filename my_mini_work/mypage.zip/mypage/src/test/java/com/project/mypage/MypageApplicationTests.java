package com.project.mypage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MypageApplicationTests {

	@Test
	void contextLoads() {
	}

}
